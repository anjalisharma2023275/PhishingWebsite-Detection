
from flask import Flask, request, jsonify
from flask_cors import CORS
import random

app = Flask(__name__)
CORS(app)

# Simulated prediction function (replace with your model later)
def predict_url(url):
    # Random prediction for now
    return random.choice(["phishing", "legitimate"])

@app.route("/check-url", methods=["POST"])
def check_url():
    data = request.get_json()
    if not data or "url" not in data:
        return jsonify({"error": "No URL provided"}), 400

    url = data["url"]
    result = predict_url(url)
    return jsonify({"status": result})

if __name__ == "__main__":
    app.run(debug=True)
